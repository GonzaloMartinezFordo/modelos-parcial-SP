# System Programming: Paginación.

## Primera parte: Preguntas teoricas

### a)  ¿Cuántos niveles de privilegio podemos definir en las estructuras de paginación?

La paginación en x86 no implementa los 4 rings de la segmentación: solo distingue dos niveles mediante el bit **U/S** de PTE/PDE:

* **Supervisor (kernel)**: U/S = 0 — pags accesibles solo desde código en nivel 0.
* **User (usario)**: U/S = 1 — pags accesibles desde niveles de menor privilegio (por ej. ring 3).


### b)  ¿Cómo se traduce una dirección lógica en una dirección física? ¿Cómo participan la dirección lógica, el registro de control `CR3`, el directorio y la tabla de páginas? Recomendación: describan el proceso en pseudocódigo

**Traducción de dirección lógica → física**

Formato de la dirección virtual de 32 bits:

```
31 ........ 22 | 21 ........ 12 | 11 ........ 0
   PDE index       PTE index          offset
```

Registro `CR3`:

* Contiene la **dirección física base** del *page directory* (alineada a 4 KiB).

Paso a paso:

1. Tomas la dirección lineal.
2. Partís sus bits en:
   • `PDE` (índice del directorio)
   • `PTE` (índice de la tabla)
   • `offset` (dentro de la página)
3. `CR3` apunta al **page directory**.
4. El CPU busca la entrada `PDE`. Si no está presente, page fault.
5. Esa entrada tiene la dirección de la **page table**.
6. En esa tabla busca `PTE`. Si no está presente, page fault.
7. La entrada de la tabla te da la **base física del pagina**.
8. Sumás el `offset`.
9. Resultado: dirección física.

PseudoCODIGO:

```
linear = translate_segment(logical)

PDE  = linear[31:22]
PTE  = linear[21:12]
offset   = linear[11:0]

pd = CR3.addr

pd_entry = pd[PDE]<>
if not pd_entry.present: page_fault()

pt = pd_entry.table_addr

pt_entry = pt[PTE]
if not pt_entry.present: page_fault()

phys = pt_entry.frame_addr + offset
return phys
```

### c)  ¿Cuál es el efecto de los siguientes atributos en las entradas de la tabla de página?

Los siguientes

| Bit   | Significado                | Efecto                                                           |
|-------|-----------------------------|-------------------------------------------------------------------|
| P     | Present                     | 1: la página está en RAM. 0: page fault si quiero acceder a ello.              |
| R/W   | Read/Write                  | 0: solo lectura. 1: lectura y escritura.                          |
| U/S   | User/Supervisor             | 0: solo kernel (rings 0–2). 1: accesible por user (ring 3).      |
| PWT   | Page Write Through          | 0: write-back. 1: write-through.                                 |
| PCD   | Page Cache Disable          | 0: permite cache. 1: deshabilita cache para esta página.         |
| A     | Accessed                    | Se pone en 1 cuando la página es leída o escrita.                |
| D     | Dirty                       | Se pone en 1 cuando la página es escrita (solo en PTE).          |

### d)  ¿Qué sucede si los atributos U/S y R/W del directorio y de la tabla de páginas difieren? ¿Cuáles terminan siendo los atributos de una página determinada en ese caso? Hint: buscar la tabla Combined Page-Directory and Page-Table Protection del manual 3 de Intel

Cuando los permisos del PDE y del PTE no coinciden, el CPU elige **el más estricto de los dos**. Nunca te va a dar más permisos que los que ambos permiten.

Es decir,

* Para **U/S**: si uno solo dice “solo supervisor”, la página queda “solo supervisor”.
* Para **R/W**: si uno solo dice “solo lectura”, la página queda “solo lectura”.

Tambine se puede pensar como un and en forma logica:

* U/S final = PDE.U/S AND PTE.U/S
* R/W final = PDE.R/W AND PTE.R/W

### e)  Suponiendo que el código de la tarea ocupa dos páginas y utilizaremos una página para la pila de la tarea. ¿Cuántas páginas hace falta pedir a la unidad de manejo de memoria para el directorio, tablas de páginas y la memoria de una tarea?

Si todo está bien alineado y las direcciones caen dentro de una sola tabla de páginas, el cálculo queda así:
#PATO
• 1 página para el Page Directory
• 1 página para la Page Table (alcanza porque una tabla cubre 4 MiB y solo necesito solo 3 entradas, donde c/ entrada de una tabla direcciona 4KiB)
• 2 páginas para el código
• 1 página para la pila

En total son 5 pags.

### g)  ¿Qué es el buffer auxiliar de traducción (translation lookaside buffer o TLB) y por qué es necesario purgarlo (`tlbflush`) al introducir modificaciones a nuestras estructuras de paginación (directorio, tabla de páginas)? ¿Qué atributos posee cada traducción en la TLB? Al desalojar una entrada determinada de la TLB ¿Se ve afectada la homóloga en la tabla original para algún caso?

El **TLB** es una caché de traducciones virtual → física que acelera la paginación.
Cuando modificamos PDE o PTE, el TLB puede tener datos viejos, así que debemos vaciar esa caché, mediante **`tlbflush`**,  para obligar al CPU a volver a leer las estructuras de paginación actualizadas. 

#PATO
Lo mas óptimo sería invalidar la linea de traducción de la entrada que modificamos para no afectar el rendimiento general pero por simplificación limpiamos toda la caché.

También se hace un **`tlbflush`** cuando se escribe un valor en **CR3**, es decir al cambiar de tarea, sin embargo hay que tener en consideración que se deben conservar aquellas entradas que estan seteadas como globales.

Cada entrada del TLB guarda:
* la dirección lineal de la página virtual (dir.lineal [31:12])
* la dirección física base de la página física (la entrada de la PT)
* los permisos U/S, R/W
* el bit de P
* bits de cache (PWT, PCD)

Al desalojar una entrada del TLB, no se modifica la entrada correspondiente en el directorio o tabla de páginas. Son estructuras independientes; la tabla es la fuente real y el TLB solo una copia temporal de la traducción.


## Tercera parte: Definiendo la MMU.

### b)  Completen el código de `copy_page`, ¿por qué es necesario mapear y desmapear las páginas de destino y fuente? ¿Qué función cumplen `SRC_VIRT_PAGE` y `DST_VIRT_PAGE`? ¿Por qué es necesario obtener el CR3 con rcr3()?

Necesitamos mapear y desmapear porque el procesador solo puede leer o escribir memoria a través de direcciones virtuales, no físicas. copy_page recibe **direcciones físicas**, pero para copiar el contenido hay que hacerlas accesibles en el **espacio virtual**.

SRC_VIRT_PAGE y DST_VIRT_PAGE son dos direcciones virtuales fijas y libres que el kernel reserva justamente para:
pongo temporalmente la pag src y la página dst, lo copio a mano, y después desmapeo para no pisar nada.

Se necesita leer CR3 con rcr3() porque CR3 contiene **la dirección física del page directory actual**. Para mapear y desmapear necesitamos saber que directorio de págs está activo. Sin CR3 no sabés dónde están las estructuras de paginación efectivas del proceso o del kernel.


