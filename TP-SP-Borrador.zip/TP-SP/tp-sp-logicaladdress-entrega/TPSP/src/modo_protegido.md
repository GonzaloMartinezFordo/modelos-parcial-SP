# System Programming: Pasaje a Modo Protegido

## Primera parte: Definiendo la GDT

### 1. Explorando el manual Intel Volumen 3: System Programming. Sección 2.2 Modes of Operation. ¿A qué nos referimos con modo real y con modo protegido en un procesador Intel? ¿Qué particularidades tiene cada modo?

El **modo real** y el **modo protegido** son dos formas en que el procesador puede operar, y determinan cómo se maneja la memoria y los permisos del sistema.

En **modo real**, el procesador usa direcciones simples combinando segmento y desplazamiento, sin protección de memoria ni privilegios. Todos los programas pueden acceder al hardware y al mismo espacio de memoria. Es el modo inicial al encender el procesador.

En **modo protegido**, la memoria se maneja mediante tablas de descriptores (GDT/LDT) que indican límites y permisos. Hay niveles de privilegio (kernel y usuario), protección entre procesos y soporte para paginación y multitarea. Es el modo usado por los sistemas operativos modernos.

### 2. Comenten en su equipo, ¿Por qué debemos hacer el pasaje de modo real a modo protegido? ¿No podríamos simplemente tener un sistema operativo en modo real? ¿Qué desventajas tendría?

El pasaje de **modo real a modo protegido** se hace porque el modo real es muy limitado: no tiene protección de memoria, solo permite acceder a 1 MB y todos los programas tienen los mismos permisos.  

Si un sistema operativo funcionara en modo real, cualquier programa podría dañar al sistema o a otros procesos, no habría seguridad, ni acceso eficiente a grandes cantidades de memoria.  

En cambio, el modo protegido permite separar memoria entre procesos, definir niveles de privilegio y usar memoria virtual. Por eso, los sistemas modernos necesitan cambiar a modo protegido para poder ser seguros, estables y aprovechar toda la memoria disponible.

### 3. Busquen el manual volumen 3 de Intel en la sección 3.4.5 Segment Descriptors. ¿Qué es la GDT? ¿Cómo es el formato de un descriptor de segmento, bit a bit? Expliquen brevemente para qué sirven los campos Limit, Base, G, P, DPL, S. También pueden referirse a los slides de la clase teórica, aunque recomendamos que se acostumbren a consultar el manual.

La **GDT (Global Descriptor Table)** es una tabla que guarda los **descriptores de segmento**, es decir, las estructuras que describen cada segmento de memoria: su dirección base, su tamaño (límite) y sus atributos de acceso y privilegio. Cada entrada de la GDT ocupa 8 bytes y define un segmento de código, datos o sistema. 


| Bits         | Campo           | Descripción  |
|---------------|------------------|-------------------|
| 0–15          | **Limit 0:15**   | Parte baja del tamaño del segmento. |
| 16–39         | **Base 0:23**    | Parte baja y media de la dirección base del segmento. |
| 40–43         | **Type**         | Indica si es código, datos o sistema, y permisos. |
| 44            | **S (Descriptor Type)** | 0 = sistema, 1 = código o datos. |
| 45–46         | **DPL (Descriptor Privilege Level)** | Nivel de privilegio (0 a 3). |
| 47            | **P (Present)**  | 1 si el segmento está en memoria. |
| 48–51         | **Limit 16:19**  | Parte alta del límite. |
| 52–54         | **AVL, L, D/B**  | Bits de control (dependen del tipo de segmento). |
| 55            | **G (Granularity)** | 0 = límite en bytes, 1 = en páginas de 4 KB. |
| 56–63         | **Base 24:31**   | Parte alta de la dirección base. |


- **Limit:** indica el tamaño máximo del segmento.  
- **Base:** dirección de inicio del segmento en memoria.  
- **G (Granularity):** define la unidad del límite (bytes o páginas de 4 KB).  
- **P (Present):** indica si el segmento está cargado en memoria.  
- **DPL (Descriptor Privilege Level):** controla qué nivel de privilegio puede acceder al segmento.  
- **S (Descriptor Type):** distingue si el descriptor es de sistema o de código/datos.

### 4. La tabla de la sección 3.4.5.1 Code- and Data-Segment Descriptor Types del volumen 3 del manual del Intel nos permite completar el Type, los bits 11, 10, 9, 8. ¿Qué combinación de bits tendríamos que usar si queremos especificar un segmento para ejecución y lectura de código?

| Bits (11–8) | Tipo de segmento | Descripción breve |
|--------------|------------------|-------------------|
| 0000 | Datos: solo lectura | No se puede escribir. |
| 0001 | Datos: lectura/escritura | Permite leer y escribir. |
| 0010 | Datos: solo lectura, expand-down | Crece hacia abajo. |
| 0011 | Datos: lectura/escritura, expand-down | Crece hacia abajo y se puede escribir. |
| 1000 | Código: solo ejecución | Solo se puede ejecutar. |
| 1001 | Código: ejecución/lectura | Se puede ejecutar y leer. |
| 1010 | Código: solo ejecución, conforming | Puede ejecutarse desde niveles de privilegio mayores. |
| 1011 | Código: ejecución/lectura, conforming | Igual que el anterior, pero también se puede leer. |

---

Por lo tanto, para un segmento de código ejecutable y legible,  
los bits 11–8 del campo Type deben ser el valor '1010'.

### 5. Inicialmente, vamos a definir los siguientes segmentos en la GDT:

a. Un segmento para código de nivel 0 ejecución/lectura

b. Un segmento para código de nivel 3 ejecución/lectura

c. Un segmento para datos de nivel 0 lectura/escritura

d. Un segmento para datos de nivel 3 lectura/escritura.
Cada uno de estos segmentos deben direccionar los primeros 817 MiB de memoria y por estar usando segmentación flat, van a estar solapados. Escriban cómo quedarían los campos de cada descriptor de cada uno de los segmentos solicitados. Especifiquen el G, límite, la base, el tipo, P, DPL, S, P, AVL, L, D/B. Pueden completar con valores hexadecimales en la siguiente planilla: GDT Entradas.

[Link al excel con la información pedida](<GDT Entradas HECHO.xlsx>)

### 6. En el archivo `gdt.h` observen las estructuras: `struct gdt_descriptor_t` y el `struct gdt_entry_t`. ¿Qué creen que contiene la variable `extern gdt_entry_t gdt;` y `extern gdt_descriptor_t GDT_DESC;`?

`gdt[]` contiene todas las entradas de la GDT, o sea los descriptores de segmento (código, datos, etc.).  
`GDT_DESC` guarda la dirección base y el tamaño de esa tabla, y se carga en el registro GDTR para que el procesador sepa dónde está la GDT.


### 10. Busquen qué hace la instrucción LGDT en el Volumen 2 del manual de Intel. Expliquen con sus palabras para qué sirve esta instrucción. En el código, ¿qué estructura indica donde está almacenada la dirección desde la cual se carga la GDT y su tamaño? ¿dónde se inicializa en el código?

#PATO
La instrucción **LGDT** le indica al procesador **dónde está la GDT y su tamaño** para que pueda usar los descriptores de segmento en modo protegido.  **LGDT** lo que hace es tomar el valor del operando fuente y cargarlo en la **GDTR**

En el código, la estructura que contiene esta información es `GDT_DESC`, que se inicializa con la dirección de `gdt[]` y su tamaño.

## Segunda parte: Pasaje a modo protegido

### 13. Investiguen en el manual de Intel sección 2.5 Control Registers, el registro CR0. ¿Deberíamos modificarlo para pasar a modo protegido? Si queremos modificar CR0, no podemos hacerlo directamente. Sólo mediante un MOV desde/hacia los registros de control (pueden leerlo en el manual en la sección citada).

Sí, para pasar a **modo protegido** hay que modificar el **bit PE (Protection Enable)** del registro **CR0**. Este bit habilita el modo protegido en el procesador.  

No se puede escribir CR0 directamente como una variable normal; hay que usar instrucciones especiales para acceder a registros de control. 
#PATO
Para debatir después: No es que se usan instrucciones especiales, sino que no se puede cargar valores directamente con un inmediato o un valor en una dirección de memoria, sino que solo se pueden cargar valores mediante registros a través de la instrucción **`MOV`** y esto solo se puede hacer con nivel de privilegio 0.

### 15. Notemos que a continuación debe hacerse un jump far para posicionarse en el código de modo protegido. Miren el volumen 2 de Intel para ver los distintos tipos de JMPs disponibles y piensen cuál sería el formato adecuado. ¿Qué usarían como selector de segmento?

Después de habilitar el modo protegido, se usa un **far jump** para actualizar **CS** y EIP al mismo tiempo. Se salta a jmp GDT_CODE_0_SEL:modo_protegido


### 22. Observen el método `screen_draw_box` en `screen.c` y la estructura `ca` en `screen.h` . ¿Qué creen que hace el método **screen_draw_box**? ¿Cómo hace para acceder a la pantalla? ¿Qué estructura usa para representar cada carácter de la pantalla y cuanto ocupa en memoria?

`screen_draw_box` dibuja un rectángulo en pantalla con un carácter y su atributo. Se indica la posición inicial, ancho y alto.  
La pantalla se trata como un array 2D de 80 columnas, y cada celda (`ca`) ocupa 2 bytes: uno para el carácter y otro para el atributo.

### 24. Resumen final, discutan en el grupo qué pasos tuvieron que hacer para activar el procesador en modo protegido. Repasen todo el código que estuvieron completando y traten de comprenderlo en detalle ¿Qué cosas les parecieron más interesantes?

Nos resulto muy interesante ver como se estructura la memoria para el procesador, y como funcionan todas sus capas de protección y privilegios que luego vemos reflejados en nuestros sistemas operativos. Además fue muy satisfactorio poder jugar con el buffer de video, los colores y el texto, viendo nuestros cambios reflejarse en la pantalla y pudiendo jugar con eso.





