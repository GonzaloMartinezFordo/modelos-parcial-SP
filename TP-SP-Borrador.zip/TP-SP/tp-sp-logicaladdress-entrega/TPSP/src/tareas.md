# System Programming: Tareas.

## Primera parte: Inicialización de tareas

### **1.** Si queremos definir un sistema que utilice sólo dos tareas, ¿Qué nuevas estructuras, cantidad de nuevas entradas en las estructuras ya definidas, y registros tenemos que configurar?¿Qué formato tienen? ¿Dónde se encuentran almacenadas?

Para un sistema con dos tareas, necesitamis:

1. **Dos TSS nuevas**
   Cada tarea necesita su propia estructura TSS, porque ahí van su ESP0, CR3, EIP, EFLAGS, registros de proposito general, reg de segmento, pilas, etc.
   El formato de la TSS es similar a un Stack en donde guardamos toda la info de una tarea.

2. **Dos entradas nuevas en la GDT**
   Cada TSS necesita un descriptor en la GDT. Agrego dos entradas más en la GDT, una por cada TSS. El descriptor en la GDT tiene el mismo formato general que cualquier descriptor de segmento, pero con tipo especial que indica la TSS.

3. **Dos selectores de segmento para esas TSSs**
   Cada descriptor nuevo en la GDT tiene su selector. Es lo que se va a usar para hacer un `ltr`(load task register). Es igual a cualquier selector de segmento normal, solo que su índice apunta al descriptor de la TSS dentro de la GDT.
4. **Task Register**
    El TR guarda el selector de la TSS actual. También guarda en caché el descriptor completo de la TSS, para poder acceder rápido a la estructura física en memoria.

Dónde está todo:
* Las TSS están alguna parte de la memoria.
* Sus descriptores están en la GDT, que también vive en memoria.
* Los selectores estan almacenadas por el scheduler

### 2. ¿A qué llamamos cambio de contexto? ¿Cuándo se produce? ¿Qué efecto tiene sobre los registros del procesador? Expliquen en sus palabras que almacena el registro TR y cómo obtiene la información necesaria para ejecutar una tarea después de un cambio de contexto.

Un **cambio de contexto** es cuando el procesador deja de ejecutar una tarea y pasa a ejecutar otra. Se produce cuando cambiamos la tarea que estamos ejecutando, y esto sucede cuando se recibe una interrupción de reloj que es handleada por el scheduler del sistema operativo, el cual cambia el valor del TR.

Cuando pasa eso, el procesador guarda todos los registros de la tarea que se está yendo (EIP, ESP, EFLAGS, generales, segmentos, etc.) en su TSS, y luego carga los registros de la otra tarea desde la TSS correspondiente. Es como cambiar de “foto completa” del estado del CPU.

El registro TR guarda el **selector de la TSS actual**. Cuando hay un cambio de contexto, se utiliza ese descriptor para localizar la TSS y cargar de ahí todos los registros necesarios para seguir ejecutando la nueva tarea desde el punto exacto donde había quedado.

### 3. Al momento de realizar un cambio de contexto el procesador va almacenar el estado actual de acuerdo al selector indicado en el registro TR y ha de restaurar aquel almacenado en la TSS cuyo selector se asigna en el jmp far. ¿Qué consideraciones deberíamos tener para poder realizar el primer cambio de contexto? ¿Y cuáles cuando no tenemos tareas que ejecutar o se encuentran todas suspendidas?

Para el **primer cambio de contexto** todavía no existe una TSS previa con un estado válido para guardar los registros actuales. Entonces, antes de hacer ese primer `jmp far` a una TSS, necesitamos: tener bien creada e inicializada la TSS de la primera tarea (EIP, ESP, CR3, segmentos, todo tiene que ser coherente); haber cargado la TR con una TSS válida.

Cuando **no tenemos tareas para ejecutar** o todas están pausadad, necesitamos tener una tarea idle. Es una TSS especial que no “hace nada útil”, pero evita que el procesador quede sin contexto. El objetivo es para que siempre exista alguna TSS lista para cargar.

### 4. ¿Qué hace el scheduler de un Sistema Operativo? ¿A qué nos referimos con que usa una política?

El **scheduler** de un sistema operativo es el que se encarga de organizar la ejecución de las tareas, gestionando el orden, el tiempo de ejecución y el intercambio de tareas. 
Cuando el scheduler **usa una política** es a que tiene un criterio para decidir cuál es la próxima tarea a ejecutar. Un ejemplo de política vista en clase sería Round Robin, todas las tareas reciben el mismo tiempo de CPU y se van rotando una detrás de otra.

### 5. En un sistema de una única CPU, ¿cómo se hace para que los programas parezcan ejecutarse en simultáneo?

Los programas parecen ejecutarse a la vez porque el sistema operativo los rota en la CPU muy rápido mediante interrupciones y cambios de contexto. Así, cada uno obtiene pequeños “pedacitos” de tiempo de CPU, suficientes para que la ejecución parezca continua y simultánea.


### 6. En tss.c se encuentran definidas las TSSs de la Tarea Inicial e Idle. Ahora, vamos a agregar el TSS Descriptor correspondiente a estas tareas en la GDT. Observen qué hace el método: tss_gdt_entry_for_task

La función `tss_gdt_entry_for_task` construye y devuelve un descriptor de TSS para poner en la GDT.

Toma la dirección de la TSS, arma los campos `base` y `limit` según dónde está y cuánto mide, marca el descriptor como presente, de nivel de privilegio 0, y con tipo de TSS de 32 bits.


### 9. Utilizando info tss, verifiquen el valor del TR. También, verifiquen los valores de los registros CR3 con creg y de los registros de segmento CS, DS, SS con sreg. ¿Por qué hace falta tener definida la pila de nivel 0 en la tss?

Es necesario porque todas las tareas deben tener una pila de nivel 0 para que cuando reciban una **interrupción** y el kernel tome el control de la ejecución tenga una pila para trabajar.

## Segunda parte: Poniendo todo en marcha

### 11. Estando definidas sched_task_offset y sched_task_selector. Y una implementación de una interrupción del reloj.

#### a)  Expliquen con sus palabras que se estaría ejecutando en cada tic del reloj línea por línea

```
  pushad    ; se guardan todos los regs de prop general en la pila para despues

  call pic_finish1      ; Le avisamos que la int ya se atendio para que vuelva a permitir interrupt externas.
  
  call sched_next_task      ; Llamamos al scheduler, nos devuelve el valor del selector de la prox tarea a ejecutar
  
  str cx        ; obtiene el selector de la TSS de la tarea actual (el que está en TR)
  cmp ax, cx        ; Comparo el prox con el actual

  je .fin       ; Si son iguales entonces no hay que hacer ningún cambio de tarea
  
  mov word [sched_task_selector], ax        ; guarda el selector de la nueva tarea en sched_task_selector
  jmp far [sched_task_offset]       ; jump far al selector de la TSS en la gdt que guardamos en la linea anterior, el que nos devolvió el scheduler
  
  .fin:
  popad ; Restauramos los valores de regs.
  iret ; Retornamos de la interrupción a la tarea
```

#### b)  En la línea que dice jmp far \[sched_task_offset\] ¿De que tamaño es el dato que estaría leyendo desde la memoria? ¿Qué indica cada uno de estos valores? ¿Tiene algún efecto el offset elegido?

`jmp far [sched_task_offset]` lee 6 bytes: 

* **Selector:** identifica la TSS en la GDT.
* **Offset:** se ignora en un salto far a TSS, porque la CPU carga el EIP que está dentro de la TSS.

¿El offset importa?
No. En un cambio de tarea por hardware, solo importa el selector.

#### c)  ¿A dónde regresa la ejecución (eip) de una tarea cuando vuelve a ser puesta en ejecución?

Cuando una tarea vuelve a ejecutarse, la CPU retoma la ejecución exactamente en el EIP que quedó guardado en su TSS en el último cambio de contexto.
La tarea continúa desde su **última instrucción pendiente**, en este caso vuelve despues del jmp far, en la etiqueta .fin de la interrupcion de reloj.

### 12. Para este Taller la cátedra ha creado un scheduler que devuelve la próxima tarea a ejecutar.

#### a) En los archivos sched.c y sched.h se encuentran definidos los métodos necesarios para el Scheduler. Expliquen cómo funciona el mismo, es decir, cómo decide cuál es la próxima tarea a ejecutar. Pueden encontrarlo en la función sched_next_task.

El scheduler recorre su arreglo de tareas como si fuera una lista circular. Desde la tarea actual busca la próxima en la cual su estado sea RUNNABLE. Si la encuentra, actualiza el índice de tarea actual y devuelve su selector de TSS. Si no hay ninguna RUNNABLE, devuelve el selector de la tarea Idle.

## Tercera parte: Tareas? Qué es eso?

### 14. Como parte de la inicialización del kernel, en kernel.asm se pide agregar una llamada a la función tasks\_init de task.c que a su vez llama a create_task. Observe las siguientes líneas:

```C
int8_t task_id = sched_add_task(gdt_id << 3);

tss_tasks[task_id] = tss_create_user_task(task_code_start[tipo]);

gdt[gdt_id] = tss_gdt_entry_for_task(&tss_tasks[task_id]);
```

#### a) ¿Qué está haciendo la función tss_gdt_entry_for_task?

Devuelve un descriptor de segmento de TSS que apunta a la TSS que le pasamos como parámetro. En este caso le pasamos la TSS que acabamos de crear para la tarea y guardamos su resultado en la entrada correspondiente de la gdt.

#### b) ¿Por qué motivo se realiza el desplazamiento a izquierda de gdt_id al pasarlo como parámetro de sched_add_task?

Porque el parámetro que toma sched_add_task es un **selector de segmento**, y los selectores de segmento tienen el índice a partir del 3 bit ya que los primeros 3 los utilizan para atributos.

### 15. Ejecuten las tareas en qemu y observen el código de estas superficialmente.

#### a) ¿Qué mecanismos usan para comunicarse con el kernel?

Es la función **syscall_draw** que realiza una interrupción número 88 y le pasa un puntero a un arreglo bidimensional de structs ca (caracter atributo) que se interpreta como una pantalla. Esta interrupción se encarga de graficar la pantalla llamando a funciones del kernel. 

Por otro lado las **interrupciones de teclado** el kernel las procesa escribiendo la información en una estructura definida en la página de memoria compartida que todas las tareas pueden acceder.

#### b) ¿Por qué creen que no hay uso de variables globales? ¿Qué pasaría si una tarea intentase escribir en su .data con nuestro sistema?

Si tuviesemos una **variable compartida** entre el Kernel y el código de usuario, habría problemas de protección. En particular si el usuario trata de escribir en esa posición se generaría un General Protection Fault ya que estaría escribiendo con nivel de privilegio 3 en un área de nivel de privilegio 0.


### 16. Observen **tareas/task_prelude.asm**. El código de este archivo se ubica al principio de las tareas.

#### a) ¿Por qué la tarea termina en un loop infinito?

Si no lo hiciera el procesador jamás se enteraría de que la tarea termino y simplemente buscaría ejecutar la siguiente instrucción, a pesar de que no exista. El procesador no esta preparado para que no haya una siguiente instrucción.

#### b) \[Opcional\] ¿Qué podríamos hacer para que esto no sea necesario?

Lo que se podría hacer es implementar una syscall que las tareas puedan llamar cuando finalizan y que le indique al sistema operativo que se las debe deshabilitar en el scheduler y que se debe cambiar a la siguiente tarea.


## Cuarta parte: Hacer nuestra propia tarea

### 18. Analicen el Makefile provisto. ¿Por qué se definen 2 "tipos" de tareas? ¿Como harían para ejecutar una tarea distinta? Cambien la tarea Snake por una tarea PongScoreboard.

Se definen 2 tipos de tarea porque `tasks.c` espera tareas agrupadas por tipo; la mayoría de las instancias ejecutadas pertenecen al mismo tipo.

Para ejecutar otra tarea, solo hace falta cambiar la tarea asociada a un tipo en el Makefile o agregar más tipos en `tasks.c` y el Makefile para crear nuevas instancias al iniciar el kernel.


### 19. Mirando la tarea Pong, ¿En que posición de memoria escribe esta tarea el puntaje que queremos imprimir? ¿Cómo funciona el mecanismo propuesto para compartir datos entre tareas?

La tarea escribe el puntaje en la **página compartida On Demand** con un offset calculado como `0xF00 + 8*task_id`, para que cada instancia tenga su espacio y no se sobreescriban datos. 

El mecanismo de compartir datos consiste en dar a cada tarea un puntero a esta memoria compartida, que contiene estructuras con información relevante como `task_id`, tick count o datos del teclado.



