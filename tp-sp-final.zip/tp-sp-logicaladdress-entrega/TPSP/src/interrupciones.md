# System Programming: Interrupciones

## Primera parte: Definiendo la IDT

### 1a. Observen que la macro `IDT_ENTRY0` corresponde a cada entrada de la IDT de nivel 0 ¿A qué se refiere cada campo? ¿Qué valores toma el campo offset?

La macro `IDT_ENTRY0` define una entrada de l IDT de nivel 0. Cada entrada indica al procesador qué hacer cuando ocurre una interrupción o excepción.  

- Los campos `offset_15_0` y `offset_31_16` indican los 16 bits menos y más significativos de la dirección de la rutina de la interrupción.  
- `segsel` es el selector del segmento de código donde está la rutina.  
- `type` define que es una interrupción de 32 bits.  
- `dpl` indica el nivel de privilegio y `present` si la rutina está cargada en memoria.  

El offset contiene la dirección completa del handler de la interrupción.


### ¿Qué oficiaría de prólogo y epílogo de estas rutinas? ¿Qué marca el `iret` y por qué no usamos `ret`?

El **prólogo** de una rutina de interrupción sirve para guardar el estado del programa. Por eso se usa pushad: guarda todos los registros generales en la pila, evitando que el handler destruya valores que el programa estaba usando.

El **epílogo** sirve para restaurar ese estado, y ahí se usa popad, que recupera todos los registros tal como estaban antes de que se disparara la interrupción.

Finalmente, se usa **iret** en lugar de ret porque una interrupción no solo debe volver a la instrucción siguiente: debe restaurar el **EIP**, el **CS** y los **EFLAGS** que el procesador guardó automáticamente al entrar a la interrupción. `ret` no restaura nada de eso, por lo que no devolvería correctamente el control al programa.

En el caso de que se produjo un cambio privilegio (por ejemplo una tarea de nivel 3 fue interrumpida, se pushean en el stack del handler el Error Code en algunos casos, EIP, CS, EFLAGS ESP y el SS el cual usamos para identificar que era de nivel 3 mediante su RPL), el iret también va a popear de la pila el **SS** y **ESP**, permitiendo restaurar su privilegio a diferencia de `ret` que no puede hacerlo.
Caso particular: Las syscalls si bien son accedidas desde el nivel 3, como las trabajas a nivel kernel, estas utilizan la pila de nivel 0 y se considera como cambio de privilegio.




